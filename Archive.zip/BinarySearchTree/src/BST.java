
public class BST {
	class Node{
		int value;
		Node left;
		Node right;
		public Node(int v){
			value = v;
			left = null;
			right = null;
		}
	}
	
	Node root;
	
	public void insert(int v){
		root = insert(root, v);
	}
	
	public Node insert(Node x, int v){
		if(x==null){
			return new Node(v);
		}
		else{
			if(x.value>v){
				x.left = insert(x.left, v);
			}
			else
				x.right = insert(x.right,v);
		}
		return x;
	}
	
	public void inorder(){
		inorder(root);
	}
	
	public void inorder(Node x){
		if(x==null)
			return;
		else{
			inorder(x.left);
			System.out.println(x.value);
			inorder(x.right);
		}
	}
	
	public void preorder(){
		preorder(root);
	}
	
	public void preorder(Node x){
		if(x==null)
			return;
		else{
			System.out.println(x.value);
			preorder(x.left);
			preorder(x.right);
		}
	}
	
	public void min(){
		Node min = min(root);
		System.out.println(min.value);
	}
	
	public Node min(Node x){
		if(x.left==null)
			return x;
		else
			return min(x.left);
	}
	
	public void deleteMin(){
		root = deleteMin(root);
	}
	
	public Node deleteMin(Node x){
		if(x.left == null)
			return x.right;
		else
			x.left = deleteMin(x.left);
		return x;
	}
	
	public void delete(int v){
		root = delete(root,v);
	}
	
	public Node delete(Node x, int v){
		if(x==null)
			return null;
		else if(x.value>v)
			x.left = delete(x.left, v);
		else if(x.value>v)
			x.right = delete(x.right, v);
		else{
			if(x.right == null)
				x = x.left;
			else{
				Node t = x;
				x = min(t.right);
				x.right = deleteMin(t.right);
				x.left = t.left;
			}
		}
		return x;
	}
	
	public int height(){
		return height(root);
	}
	
	public int height(Node x){
		if(x == null)
			return -1;
		else{
			int lh = height(x.left);
			int rh = height(x.right);
			return Math.max(lh+1, rh+1);
		}
	}
	
	public void floor(int v){
		Node x = floor(root, v);
		System.out.println(x.value);
	}
	
	public Node floor(Node x, int v){
		if(x==null)
			return null;
		else if(x.value>v)
			return floor(x.left,v);
		else if(x.value==v)
			return x;
		Node t = floor(x.right,v);
		if(t!=null)
			return t;
		else
			return x;
	}
	
	/*public BST reverse(){
		BST tree = new BST();
		tree.root = reverse(root);
		return tree;
	}*/
	
	public void reverse(){	
		root = reverse(root);
	}
	
	public Node reverse(Node x){
		if(x==null)
			return null;
		else{
			Node temp1= reverse(x.left);
			Node temp2 = reverse(x.right);
			x.right = temp1;
			x.left = temp2;
		}
		return x;
	}
	
	//Binary Tree from preorder O(n) time
	
	public void createTree(int[] a){
		root  = createTree(a, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
	}
	
	public Node createTree(int[]a, int i, int min, int max){
		if(i>=a.length){
			return null;
		}
		else if(!(a[i]<max && a[i]>min))
			return null;
		Node x = new Node(a[i]);
		i++;
		x.left = createTree ( a, i, min , x.value);
		x.right = createTree ( a, i, x.value , max);
		return x;
	}
	
	public static void main(String[] arg){
		BST tree = new BST();
		/*tree.insert(2);
		tree.insert(1);
		tree.insert(3);
		//tree.preorder();
		//tree.floor(3);
		//System.out.println(tree.height());
		tree.reverse();
		tree.inorder();*/
		int[] a = {5,3,4};
		tree.createTree(a);
		tree.inorder();
	}
}
